package com.inghub.inghub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InghubApplication {

	public static void main(String[] args) {
		SpringApplication.run(InghubApplication.class, args);
	}

}
